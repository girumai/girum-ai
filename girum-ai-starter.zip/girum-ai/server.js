import 'dotenv/config';
import express from 'express';
import OpenAI from 'openai';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const port = Number(process.env.PORT || 3000);
const apiKey = process.env.OPENAI_API_KEY;
const openai = apiKey ? new OpenAI({ apiKey }) : null;
const __dirname = path.dirname(fileURLToPath(import.meta.url));

app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/health', (_req, res) => res.json({ ok: true, configured: Boolean(openai) }));

app.post('/api/chat', async (req, res) => {
  try {
    if (!openai) return res.status(503).json({ error: 'AI service is not configured yet. Add OPENAI_API_KEY on the server.' });
    const { messages = [], language = 'auto' } = req.body || {};
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 30) {
      return res.status(400).json({ error: 'Send between 1 and 30 messages.' });
    }
    const safeMessages = messages.slice(-20).map(m => ({
      role: m.role === 'assistant' ? 'assistant' : 'user',
      content: String(m.content || '').slice(0, 8000)
    }));
    const languageInstruction = language === 'am' ? 'Reply in Amharic.' :
      language === 'en' ? 'Reply in English.' :
      'Reply in the same language as the user (English or Amharic).';
    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
      instructions: `You are Girum AI, a helpful, accurate, friendly assistant. Support English and Amharic. ${languageInstruction} If unsure, say so. Do not claim to perform actions you cannot perform.`,
      input: safeMessages.map(m => ({ role: m.role, content: m.content }))
    });
    res.json({ reply: response.output_text || 'I could not produce a response. Please try again.' });
  } catch (err) {
    console.error('chat error', err?.message || err);
    res.status(500).json({ error: 'Girum AI could not answer right now. Please try again.' });
  }
});

app.post('/api/image', async (req, res) => {
  try {
    if (!openai) return res.status(503).json({ error: 'AI service is not configured yet.' });
    const prompt = String(req.body?.prompt || '').trim().slice(0, 2000);
    if (!prompt) return res.status(400).json({ error: 'Please enter an image description.' });
    const result = await openai.images.generate({ model: 'gpt-image-1', prompt, size: '1024x1024' });
    res.json({ image: `data:image/png;base64,${result.data[0].b64_json}` });
  } catch (err) {
    console.error('image error', err?.message || err);
    res.status(500).json({ error: 'Image generation failed. Check API access and billing, then try again.' });
  }
});

app.listen(port, () => console.log(`Girum AI running at http://localhost:${port}`));
